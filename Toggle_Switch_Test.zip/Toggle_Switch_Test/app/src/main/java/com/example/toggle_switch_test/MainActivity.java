package com.example.toggle_switch_test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity implements RadioGroup.OnCheckedChangeListener {
    RadioGroup mRadioGroupData;

    public TextView mStateTextView;

    public Button mBtOn;
    public Button mBtOff;
    public int result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final ToggleButton tb = (ToggleButton) this.findViewById(R.id.toggleButton);

        tb.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                if (tb.isChecked()) {
                    ReceiveLedValue(255);
                    tb.setBackgroundDrawable(
                            getResources().getDrawable(R.drawable.on)
                    );
                } else {
                    ReceiveLedValue(0);
                    tb.setBackgroundDrawable(
                            getResources().getDrawable(R.drawable.off)
                    );
                } // end if
            } // end onClick()
        });

        mRadioGroupData = (RadioGroup) findViewById(R.id.RadioGroup01);
        mRadioGroupData.setOnCheckedChangeListener(this);


        mStateTextView = (TextView) findViewById(R.id.my_prt_state);
        mBtOn = (Button) findViewById(R.id.BT01);
        mBtOff = (Button) findViewById(R.id.BT02);


        mBtOn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result = ReceiveBuzzerValue(1);
                if (result < 0)
                    mStateTextView.setText("Device Open Error!");
                else
                    Toast.makeText(getApplicationContext(), "내 위치 알림 중", Toast.LENGTH_SHORT).show();
            }
        });


        mBtOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                result = ReceiveBuzzerValue(0);
                if (result < 0)
                    mStateTextView.setText("Device Open Error!");
                else
                    Toast.makeText(getApplicationContext(), "내 위치 알림 종료", Toast.LENGTH_SHORT).show();
            }
        });


    }


    @Override
    public void onCheckedChanged(RadioGroup group, int checkedId) {

        switch (checkedId) {
            case R.id.RB01:
                ReceiveLedValue(17); //LED 1
                break;
            case R.id.RB02:
                ReceiveLedValue(51); //LED 2
                break;
            case R.id.RB03:
                ReceiveLedValue(119); //LED 3
                break;
        }
    }

    static {
        System.loadLibrary("native-lib");
    }

    public native String ReceiveLedValue(int x);

    public native int ReceiveBuzzerValue(int y);
}
