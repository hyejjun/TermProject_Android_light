#include <string.h>
#include <jni.h>
#include <android/log.h>
#include <fcntl.h>
#include <unistd.h>

#define LED_DEVICE "/dev/fpga_led"
#define BUZZER_DEVICE "/dev/fpga_buzzer"

int fpga_led(int x)
{
    int dev;
    unsigned char data;
    unsigned char retval;

    unsigned char val;

    val = (unsigned char)x;

    dev = open(LED_DEVICE, O_RDWR);
    if (dev<0){
        __android_log_print(ANDROID_LOG_INFO, "Device Open Error", "Driver = %d", x);
    } else{
        __android_log_print(ANDROID_LOG_INFO, "Device Open Success", "Driver = %d", x);
        write(dev, &val, sizeof(unsigned char));
        close(dev);
    }
    return 0;
}


int fpga_buzzer(int y)
{
    int dev;
    unsigned char data;
    unsigned char retval;

    data = (char)y;

    dev = open(BUZZER_DEVICE, O_RDWR);
    if (dev<0){
        __android_log_print(ANDROID_LOG_INFO,"Device Open Error", "Driver = %d", y);
        return -1;
    } else{
        __android_log_print(ANDROID_LOG_INFO,"Device Open Success","Driver = %d", y);
        write(dev,&data,1);
        close(dev);
        return 0;
    }
}


extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_toggle_1switch_1test_MainActivity_ReceiveLedValue(JNIEnv *env, jobject thiz, jint val)
{
    // TODO: implement ReceiveLedValue()
    __android_log_print(ANDROID_LOG_INFO, "FpgaLedJniExample", "led value = %d", val);
    fpga_led(val);

    return NULL;
}



extern "C"
JNIEXPORT jint JNICALL
Java_com_example_toggle_1switch_1test_MainActivity_ReceiveBuzzerValue(JNIEnv *env, jobject thiz,
                                                                      jint y) {
    // TODO: implement ReceiveBuzzerValue()

    jint result;
    __android_log_print(ANDROID_LOG_INFO, "FpgaBuzzerExample", " value = %d",y);
    result = fpga_buzzer(y);

    return result;
}